#!/usr/bin/env bash

./HTML-raw-to-full.sh
./createIndex.sh
./exportPDF.sh